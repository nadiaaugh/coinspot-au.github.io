<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="https://www.coinspot.com.au/public/img/coinspot-sml-white.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="480">
<meta property="og:image:height" content="480">
<title>Buy &amp; Sell Bitcoin, Dogecoin, Litecoin | CoinSpot</title>
<link rel="shortcut icon" href="https://www.coinspot.com.au/public/img/favicon.png?v=207">
<link rel="apple-touch-icon" sizes="57x57" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="https://www.coinspot.com.au/public/img/favicons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="https://www.coinspot.com.au/public/img/favicons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://www.coinspot.com.au/public/img/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="https://www.coinspot.com.au/public/img/favicons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://www.coinspot.com.au/public/img/favicons/favicon-16x16.png">
<link rel="manifest" href="https://www.coinspot.com.au/public/img/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/public/img/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" href="/CS_files/coinspot.min.css">
<script type="text/javascript" async="" src="/CS_files/recaptcha__id.js" crossorigin="anonymous" integrity="sha384-fdEXFfOQV5OEYk4KY3rgw7BduBwjkcihfYu1fBpQQthKBKj4qCVH1qwTnIJlPLBd" nonce=""></script><script nonce="" src="/CS_files/coinspot.min.js"></script>
<script nonce="" src="/CS_files/brhash.min.js"></script>
<script nonce="" src="/CS_files/bootstrap-sortable.js"></script>
<link rel="stylesheet" type="text/css" href="/CS_files/flaticon.css">
<link rel="stylesheet" type="text/css" href="/CS_files/font.css">
<link rel="stylesheet" href="/CS_files/main.css">
<script nonce="" src="/CS_files/main.js"></script>
<style>
    /* Grid system */
    
    .grid{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-15px;margin-left:-15px}.no-gutters{margin-right:0;margin-left:0}.grid.no-gutters>.col,.grid.no-gutters>[class*=col-]{padding-right:0;padding-left:0}.grid>.col,.grid>.col-1,.grid>.col-10,.grid>.col-11,.grid>.col-12,.grid>.col-2,.grid>.col-3,.grid>.col-4,.grid>.col-5,.grid>.col-6,.grid>.col-7,.grid>.col-8,.grid>.col-9,.grid>.col-auto,.grid>.col-lg,.grid>.col-lg-1,.grid>.col-lg-10,.grid>.col-lg-11,.grid>.col-lg-12,.grid>.col-lg-2,.grid>.col-lg-3,.grid>.col-lg-4,.grid>.col-lg-5,.grid>.col-lg-6,.grid>.col-lg-7,.grid>.col-lg-8,.grid>.col-lg-9,.grid>.col-lg-auto,.grid>.col-md,.grid>.col-md-1,.grid>.col-md-10,.grid>.col-md-11,.grid>.col-md-12,.grid>.col-md-2,.grid>.col-md-3,.grid>.col-md-4,.grid>.col-md-5,.grid>.col-md-6,.grid>.col-md-7,.grid>.col-md-8,.grid>.col-md-9,.grid>.col-md-auto,.grid>.col-sm,.grid>.col-sm-1,.grid>.col-sm-10,.grid>.col-sm-11,.grid>.col-sm-12,.grid>.col-sm-2,.grid>.col-sm-3,.grid>.col-sm-4,.grid>.col-sm-5,.grid>.col-sm-6,.grid>.col-sm-7,.grid>.col-sm-8,.grid>.col-sm-9,.grid>.col-sm-auto,.grid>.col-xl,.grid>.col-xl-1,.grid>.col-xl-10,.grid>.col-xl-11,.grid>.col-xl-12,.grid>.col-xl-2,.grid>.col-xl-3,.grid>.col-xl-4,.grid>.col-xl-5,.grid>.col-xl-6,.grid>.col-xl-7,.grid>.col-xl-8,.grid>.col-xl-9,.grid>.col-xl-auto{position:relative;width:100%;min-height:1px;padding-right:15px;padding-left:15px}.grid>.col{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%}.grid>.col-auto{-webkit-box-flex:0;-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.grid>.col-1{-webkit-box-flex:0;-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.grid>.col-2{-webkit-box-flex:0;-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.grid>.col-3{-webkit-box-flex:0;-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.grid>.col-4{-webkit-box-flex:0;-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.grid>.col-5{-webkit-box-flex:0;-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.grid>.col-6{-webkit-box-flex:0;-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.grid>.col-7{-webkit-box-flex:0;-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.grid>.col-8{-webkit-box-flex:0;-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.grid>.col-9{-webkit-box-flex:0;-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.grid>.col-10{-webkit-box-flex:0;-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.grid>.col-11{-webkit-box-flex:0;-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.grid>.col-12{-webkit-box-flex:0;-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.grid>.order-first{-webkit-box-ordinal-group:0;-ms-flex-order:-1;order:-1}.grid>.grid>.order-last{-webkit-box-ordinal-group:14;-ms-flex-order:13;order:13}.grid>.order-0{-webkit-box-ordinal-group:1;-ms-flex-order:0;order:0}.grid>.order-1{-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.grid>.order-2{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.grid>.order-3{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.grid>.order-4{-webkit-box-ordinal-group:5;-ms-flex-order:4;order:4}.grid>.order-5{-webkit-box-ordinal-group:6;-ms-flex-order:5;order:5}.grid>.order-6{-webkit-box-ordinal-group:7;-ms-flex-order:6;order:6}.grid>.order-7{-webkit-box-ordinal-group:8;-ms-flex-order:7;order:7}.grid>.order-8{-webkit-box-ordinal-group:9;-ms-flex-order:8;order:8}.grid>.order-9{-webkit-box-ordinal-group:10;-ms-flex-order:9;order:9}.grid>.order-10{-webkit-box-ordinal-group:11;-ms-flex-order:10;order:10}.grid>.order-11{-webkit-box-ordinal-group:12;-ms-flex-order:11;order:11}.grid>.order-12{-webkit-box-ordinal-group:13;-ms-flex-order:12;order:12}.grid>.offset-1{margin-left:8.333333%}.grid>.offset-2{margin-left:16.666667%}.grid>.offset-3{margin-left:25%}.grid>.offset-4{margin-left:33.333333%}.grid>.offset-5{margin-left:41.666667%}.grid>.offset-6{margin-left:50%}.grid>.offset-7{margin-left:58.333333%}.grid>.offset-8{margin-left:66.666667%}.grid>.grid>.offset-9{margin-left:75%}.grid>.offset-10{margin-left:83.333333%}.grid>.offset-11{margin-left:91.666667%}@media (min-width:576px){.grid>.col-sm{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%}.grid>.col-sm-auto{-webkit-box-flex:0;-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.grid>.col-sm-1{-webkit-box-flex:0;-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.grid>.col-sm-2{-webkit-box-flex:0;-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.grid>.col-sm-3{-webkit-box-flex:0;-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.grid>.col-sm-4{-webkit-box-flex:0;-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.grid>.col-sm-5{-webkit-box-flex:0;-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.grid>.col-sm-6{-webkit-box-flex:0;-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.grid>.col-sm-7{-webkit-box-flex:0;-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.grid>.col-sm-8{-webkit-box-flex:0;-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.grid>.col-sm-9{-webkit-box-flex:0;-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.grid>.col-sm-10{-webkit-box-flex:0;-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.grid>.col-sm-11{-webkit-box-flex:0;-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.grid>.col-sm-12{-webkit-box-flex:0;-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.grid>.order-sm-first{-webkit-box-ordinal-group:0;-ms-flex-order:-1;order:-1}.grid>.order-sm-last{-webkit-box-ordinal-group:14;-ms-flex-order:13;order:13}.grid>.order-sm-0{-webkit-box-ordinal-group:1;-ms-flex-order:0;order:0}.grid>.order-sm-1{-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.grid>.order-sm-2{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.grid>.order-sm-3{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.grid>.order-sm-4{-webkit-box-ordinal-group:5;-ms-flex-order:4;order:4}.grid>.order-sm-5{-webkit-box-ordinal-group:6;-ms-flex-order:5;order:5}.grid>.order-sm-6{-webkit-box-ordinal-group:7;-ms-flex-order:6;order:6}.grid>.order-sm-7{-webkit-box-ordinal-group:8;-ms-flex-order:7;order:7}.grid>.order-sm-8{-webkit-box-ordinal-group:9;-ms-flex-order:8;order:8}.grid>.order-sm-9{-webkit-box-ordinal-group:10;-ms-flex-order:9;order:9}.grid>.order-sm-10{-webkit-box-ordinal-group:11;-ms-flex-order:10;order:10}.grid>.order-sm-11{-webkit-box-ordinal-group:12;-ms-flex-order:11;order:11}.grid>.order-sm-12{-webkit-box-ordinal-group:13;-ms-flex-order:12;order:12}.grid>.offset-sm-0{margin-left:0}.grid>.offset-sm-1{margin-left:8.333333%}.grid>.offset-sm-2{margin-left:16.666667%}.grid>.offset-sm-3{margin-left:25%}.grid>.offset-sm-4{margin-left:33.333333%}.grid>.offset-sm-5{margin-left:41.666667%}.grid>.offset-sm-6{margin-left:50%}.grid>.offset-sm-7{margin-left:58.333333%}.grid>.offset-sm-8{margin-left:66.666667%}.grid>.offset-sm-9{margin-left:75%}.grid>.offset-sm-10{margin-left:83.333333%}.grid>.offset-sm-11{margin-left:91.666667%}}@media (min-width:768px){.grid>.col-md{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%}.grid>.col-md-auto{-webkit-box-flex:0;-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.grid>.col-md-1{-webkit-box-flex:0;-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.grid>.col-md-2{-webkit-box-flex:0;-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.grid>.col-md-3{-webkit-box-flex:0;-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.grid>.col-md-4{-webkit-box-flex:0;-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.grid>.col-md-5{-webkit-box-flex:0;-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.grid>.col-md-6{-webkit-box-flex:0;-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.grid>.col-md-7{-webkit-box-flex:0;-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.grid>.col-md-8{-webkit-box-flex:0;-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.grid>.col-md-9{-webkit-box-flex:0;-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.grid>.col-md-10{-webkit-box-flex:0;-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.grid>.col-md-11{-webkit-box-flex:0;-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.grid>.col-md-12{-webkit-box-flex:0;-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.grid>.order-md-first{-webkit-box-ordinal-group:0;-ms-flex-order:-1;order:-1}.grid>.order-md-last{-webkit-box-ordinal-group:14;-ms-flex-order:13;order:13}.grid>.order-md-0{-webkit-box-ordinal-group:1;-ms-flex-order:0;order:0}.grid>.order-md-1{-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.grid>.order-md-2{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.grid>.order-md-3{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.grid>.order-md-4{-webkit-box-ordinal-group:5;-ms-flex-order:4;order:4}.grid>.order-md-5{-webkit-box-ordinal-group:6;-ms-flex-order:5;order:5}.grid>.order-md-6{-webkit-box-ordinal-group:7;-ms-flex-order:6;order:6}.grid>.order-md-7{-webkit-box-ordinal-group:8;-ms-flex-order:7;order:7}.grid>.order-md-8{-webkit-box-ordinal-group:9;-ms-flex-order:8;order:8}.grid>.order-md-9{-webkit-box-ordinal-group:10;-ms-flex-order:9;order:9}.grid>.order-md-10{-webkit-box-ordinal-group:11;-ms-flex-order:10;order:10}.grid>.order-md-11{-webkit-box-ordinal-group:12;-ms-flex-order:11;order:11}.grid>.order-md-12{-webkit-box-ordinal-group:13;-ms-flex-order:12;order:12}.grid>.offset-md-0{margin-left:0}.grid>.offset-md-1{margin-left:8.333333%}.grid>.offset-md-2{margin-left:16.666667%}.grid>.offset-md-3{margin-left:25%}.grid>.offset-md-4{margin-left:33.333333%}.grid>.offset-md-5{margin-left:41.666667%}.grid>.offset-md-6{margin-left:50%}.grid>.offset-md-7{margin-left:58.333333%}.grid>.offset-md-8{margin-left:66.666667%}.grid>.offset-md-9{margin-left:75%}.grid>.offset-md-10{margin-left:83.333333%}.grid>.offset-md-11{margin-left:91.666667%}}@media (min-width:992px){.grid>.col-lg{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%}.grid>.col-lg-auto{-webkit-box-flex:0;-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.grid>.col-lg-1{-webkit-box-flex:0;-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.grid>.col-lg-2{-webkit-box-flex:0;-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.grid>.col-lg-3{-webkit-box-flex:0;-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.grid>.col-lg-4{-webkit-box-flex:0;-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.grid>.col-lg-5{-webkit-box-flex:0;-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.grid>.col-lg-6{-webkit-box-flex:0;-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.grid>.col-lg-7{-webkit-box-flex:0;-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.grid>.col-lg-8{-webkit-box-flex:0;-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.grid>.col-lg-9{-webkit-box-flex:0;-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.grid>.col-lg-10{-webkit-box-flex:0;-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.grid>.col-lg-11{-webkit-box-flex:0;-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.grid>.col-lg-12{-webkit-box-flex:0;-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.grid>.order-lg-first{-webkit-box-ordinal-group:0;-ms-flex-order:-1;order:-1}.grid>.order-lg-last{-webkit-box-ordinal-group:14;-ms-flex-order:13;order:13}.grid>.order-lg-0{-webkit-box-ordinal-group:1;-ms-flex-order:0;order:0}.grid>.order-lg-1{-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.grid>.order-lg-2{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.grid>.order-lg-3{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.grid>.order-lg-4{-webkit-box-ordinal-group:5;-ms-flex-order:4;order:4}.grid>.order-lg-5{-webkit-box-ordinal-group:6;-ms-flex-order:5;order:5}.grid>.order-lg-6{-webkit-box-ordinal-group:7;-ms-flex-order:6;order:6}.grid>.order-lg-7{-webkit-box-ordinal-group:8;-ms-flex-order:7;order:7}.grid>.order-lg-8{-webkit-box-ordinal-group:9;-ms-flex-order:8;order:8}.grid>.order-lg-9{-webkit-box-ordinal-group:10;-ms-flex-order:9;order:9}.grid>.order-lg-10{-webkit-box-ordinal-group:11;-ms-flex-order:10;order:10}.grid>.order-lg-11{-webkit-box-ordinal-group:12;-ms-flex-order:11;order:11}.grid>.order-lg-12{-webkit-box-ordinal-group:13;-ms-flex-order:12;order:12}.grid>.offset-lg-0{margin-left:0}.grid>.offset-lg-1{margin-left:8.333333%}.grid>.offset-lg-2{margin-left:16.666667%}.grid>.offset-lg-3{margin-left:25%}.grid>.offset-lg-4{margin-left:33.333333%}.grid>.offset-lg-5{margin-left:41.666667%}.grid>.offset-lg-6{margin-left:50%}.grid>.offset-lg-7{margin-left:58.333333%}.grid>.offset-lg-8{margin-left:66.666667%}.grid>.offset-lg-9{margin-left:75%}.grid>.offset-lg-10{margin-left:83.333333%}.grid>.offset-lg-11{margin-left:91.666667%}}@media (min-width:1200px){.grid>.col-xl{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%}.grid>.col-xl-auto{-webkit-box-flex:0;-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.grid>.col-xl-1{-webkit-box-flex:0;-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.grid>.col-xl-2{-webkit-box-flex:0;-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.grid>.col-xl-3{-webkit-box-flex:0;-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.grid>.col-xl-4{-webkit-box-flex:0;-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.grid>.col-xl-5{-webkit-box-flex:0;-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.grid>.col-xl-6{-webkit-box-flex:0;-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.grid>.col-xl-7{-webkit-box-flex:0;-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.grid>.col-xl-8{-webkit-box-flex:0;-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.grid>.col-xl-9{-webkit-box-flex:0;-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.grid>.col-xl-10{-webkit-box-flex:0;-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.grid>.col-xl-11{-webkit-box-flex:0;-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.grid>.col-xl-12{-webkit-box-flex:0;-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.grid>.order-xl-first{-webkit-box-ordinal-group:0;-ms-flex-order:-1;order:-1}.grid>.order-xl-last{-webkit-box-ordinal-group:14;-ms-flex-order:13;order:13}.grid>.order-xl-0{-webkit-box-ordinal-group:1;-ms-flex-order:0;order:0}.grid>.order-xl-1{-webkit-box-ordinal-group:2;-ms-flex-order:1;order:1}.grid>.order-xl-2{-webkit-box-ordinal-group:3;-ms-flex-order:2;order:2}.grid>.order-xl-3{-webkit-box-ordinal-group:4;-ms-flex-order:3;order:3}.grid>.order-xl-4{-webkit-box-ordinal-group:5;-ms-flex-order:4;order:4}.grid>.order-xl-5{-webkit-box-ordinal-group:6;-ms-flex-order:5;order:5}.grid>.order-xl-6{-webkit-box-ordinal-group:7;-ms-flex-order:6;order:6}.grid>.order-xl-7{-webkit-box-ordinal-group:8;-ms-flex-order:7;order:7}.grid>.order-xl-8{-webkit-box-ordinal-group:9;-ms-flex-order:8;order:8}.grid>.order-xl-9{-webkit-box-ordinal-group:10;-ms-flex-order:9;order:9}.grid>.order-xl-10{-webkit-box-ordinal-group:11;-ms-flex-order:10;order:10}.grid>.order-xl-11{-webkit-box-ordinal-group:12;-ms-flex-order:11;order:11}.grid>.order-xl-12{-webkit-box-ordinal-group:13;-ms-flex-order:12;order:12}.grid>.offset-xl-0{margin-left:0}.grid>.offset-xl-1{margin-left:8.333333%}.grid>.offset-xl-2{margin-left:16.666667%}.grid>.offset-xl-3{margin-left:25%}.grid>.offset-xl-4{margin-left:33.333333%}.grid>.offset-xl-5{margin-left:41.666667%}.grid>.offset-xl-6{margin-left:50%}.grid>.offset-xl-7{margin-left:58.333333%}.grid>.offset-xl-8{margin-left:66.666667%}.grid>.offset-xl-9{margin-left:75%}.grid>.offset-xl-10{margin-left:83.333333%}.grid>.offset-xl-11{margin-left:91.666667%}}
    
    
    /* New Styles */
    
    .bg-blue {
      background-color: #004FEE !important;
    }
    
    .bg-paleblue {
      background-color: #F5F8FF !important;
    }
    
    .bg-oldblue {
      background-color: #c7def6 !important;
    }
    
    .heading-1 {
      font-family: "MontSmBd";
      font-size: 36px;
      line-height: 40px;
      letter-spacing: -0.03rem;
      color: #17181C !important;
    }
    
    .heading-text {
      font-family: "MontSmBd" !important;
      font-size: 18px;
      line-height: 24px;
      color: #004FEE !important
    }
    
    .sub-heading {
      font-size: 14px;
      line-height: 22px;
      font-family: "Mont";
    }
    
    .section-heading {
      font-family: "MontSmBd" !important;
      color: #17181C !important;
      font-size: 25px;
      line-height: 33px;
      letter-spacing: -0.03rem;
    }
    
    .section-heading-lg {
      font-family: "MontSmBd" !important;
      color: #17181C !important;
      font-size: 25px;
      line-height: 33px;
      letter-spacing: -0.03rem;
    }
    
    .text-default, .text-default-600 {
      font-family: "Mont";
      font-size: 14px;
      line-height: 24px;
      color: #75798A;
    }
    .text-default-600 { color: #666978; }
    
    .text-dark {
      font-family: 'Mont';
      font-size: 14px;
      line-height: 24px;
      color: #17181C;
    }
    
    .gradient-text-1 {
      background: -webkit-linear-gradient(90deg, #6EF3E8 0%, #004FEE 100%);
      background: linear-gradient(90deg, #6EF3E8 0%, #004FEE 100%);
      -webkit-background-clip: text;
      background-clip: text;
      -webkit-text-fill-color: transparent;
      padding: 5px 0;
      -webkit-box-decoration-break: clone;
    }
    .gradient-text-2 {
      background: -webkit-linear-gradient(270deg, #6EF3E8 0%, #004FEE 100%);
      background: linear-gradient(270deg, #6EF3E8 0%, #004FEE 100%);
      -webkit-background-clip: text;
      background-clip: text;
      -webkit-text-fill-color: transparent;
      padding: 5px 0;
    }
    
    .navgroup {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
    }
    
    .navgroup, .navlight, .navblue {
      font-family: "Mont";
      height: 70px;
    }
    
    .navlight {
      background-color: transparent !important;
    }
    
    .navblue {
      background-color: #004FEE !important;
    }
    
    .navitem {
      font-size: 14px;
    }
    
    .navlogo {
      font-size: 22px;
      line-height: 2em;
    }
    
    .navlogo > img {
      height: 35px;
      width: 35px;
      margin-right: 7px;
      margin-bottom: 2px;
    }
    
    .navitem.selected {
      border-bottom: 2px #2F3037 solid;
      padding: 3px 0;
    }
    
    .navblue .navitem.selected {
      border-bottom: 2px #fff solid;
    }
    
    .navitem:not(:last-child) {
      margin-right: 25px;
    }
    
    .navlight .navitem,
    .navlight .navlogo {
      color: #2F3037;
    }
    
    .navblue .navitem,
    .navblue .navlogo {
      color: #fff;
    }
    
    .navblue .navitem.btn-primary {
      background-color: #fff !important;
      border-color: #fff !important;
      color: #004FEE !important;
    }
    
    .navlight .navitem.btn-primary {
      background-color: #004FEE !important;
      border-color: #004FEE !important;
    }
    
    .sidenav-toggle {
      cursor: pointer;
    }
    
    .hamburger > div {
      height: 3px;
      width: 30px;
      background-color: #fff;
      border-radius: 1.5px !important;
    }
    
    .hamburger > div:not(:last-child) {
      margin-bottom: 6px;
    }
    
    .sidenav-overlay {
      display: none;
      position: fixed;
      background-color: rgba(6,52,92,.6);
      height: 100vh;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 9999;
    }
    
    #sidenav {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: 246px;
      min-height: 100vh;
      background: #06345C;
      color: #fff;
      transition: all 0.3s;   
      z-index: 99999;
      overflow-y: scroll;
    }
    
    #sidenav.hidden {
      left: -246px;
    }
    
    #sidenav .sidenav-header {
      padding: 20px;
    }
    
    #sidenav ul li a {
      padding: 10px;
      padding-bottom: 20px;
      font-size: 0.9em;
      display: block;
      color: #fff;
      border-bottom: solid 1px #99a1a7;
      margin-left: 30px;
      margin-right: 30px;
    }
    
    #sidenav ul li.active > a, a[aria-expanded="true"] {
      color: #fff;
      background: #516a89;
    }
    
    #sidenav ul li a img {
      padding-right: 15px;
      width: 40px;
    }
    
    nav#sidenav i[class^="flaticon-"]:before, nav#sidenav i[class*=" flaticon-"]:before {
      font-size: 24px;
      padding-right: 15px;
      top: 6px;
    }
    
    .footer-group {
      list-style-type: none;
    }
    
    .footer-group a {
      font-family: "Mont" !important;
      font-size: 14px !important;
      color: #00050E !important;
    }
    
    .footer-group li {
      margin-top: 10px;
    }
    
    .footer-group .footer-group-title {
      font-family: "MontSmBd";
      color: #004FEE;
      margin-bottom: 15px;
      margin-top: 20px;
    }
    
    .footer-logo {
      color: #00050E !important;
      font-size: 22px;
      line-height: 2em;
    }
    
    .footer-logo > img {
      height: 35px;
      width: 35px;
      margin-right: 7px;
      margin-bottom: 2px;
    }
    
    .footer-text {
      font-family: "Mont";
      font-size: 12px;
      color: #00050E;
    }
    
    .iso-text {
      font-family: "Mont";
      font-size: 14px;
      color: #00050E;
      line-height: 1.6rem;
      margin-top: 5px;
      margin-left: 5px;
    }
    
    .iso-text strong {
      font-family: "MontBd";
    }
    
    .text-blue {
      color: #004FEE !important;
    }
    
    .btn-outline-grey {
    	font-size: 10px;
    	font-weight: 500;
    	letter-spacing: 0.05rem;
    	color: #666978;
    	background: transparent;
    	border: 1px solid #F4F4F6;
    	padding: 3px 10px;
    }
    
    .cspanel {
        padding: 10px;
        padding-top: 20px;
        background-color: #fff;
        border: 1px solid #f7f7f8;
        border-radius: 6px !important;
        box-shadow: 0 2px 5px 0 rgb(164 173 186 / 25%);
    }
    
    .cspanel-margin {
        margin: 10px;
    }
    
    .cspanel .panel-heading {
        border-bottom: 0;
        color: #666978 !important;
        text-transform: uppercase;
        font-size: 16px;
    }
    
    .cspanel .table>thead>tr>th {
        border-bottom: 1px solid #EBEDFF;
        text-transform: uppercase;
        color: #ACAEB9;
        font-size: 12px;
    }
    
    .cspanel .table>thead>tr>th, 
    .cspanel .table>tbody>tr>th, 
    .cspanel .table>tfoot>tr>th, 
    .cspanel .table>thead>tr>td, 
    .cspanel .table>tbody>tr>td, 
    .cspanel .table>tfoot>tr>td {
        border-top: 1px solid #F4F4F6;
        color: #75798A;
        line-height: 44px;
    }
    
    .cspanel .table>thead>tr>td .btn-link-cancel, 
    .cspanel .table>tbody>tr>td .btn-link-cancel, 
    .cspanel .table>tfoot>tr>td .btn-link-cancel {
        color: #B11B1B;
        cursor: pointer;
        border: none;
        background-color: transparent;
    }
    
    .cspanel .btn-group .btn {
        text-transform: uppercase;
        border-color: #E3E4E8;
        color: #75798A !important;
    }
    
    .cspanel .btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle) {
        border-bottom-right-radius: 0 !important;
        border-top-right-radius: 0 !important;
    }
    
    .cspanel .btn-group>.btn:last-child:not(:first-child), .btn-group>.dropdown-toggle:not(:first-child) {
        border-bottom-left-radius: 0;
        border-top-left-radius: 0;
    }
    
    .cspanel .btn-group .btn:active, .cspanel .btn-group .btn.active {
        background-color: #c7def6 !important;
        color: #0073DD !important;
        box-shadow: none;
    }
    
    .card {
    	background-color: #fff;
    	padding: 15px;
    	box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    	border-radius: 4px !important;
    }
    
    .card-sm {
      padding: 10px;
    }
    
    .card-heading {
    	font-size: 12px;
    	font-weight: 600;
    	color: #666978;
    	line-height: 1.2rem;
    	margin-bottom: 15px;
    }
    
    .card-sm .card-heading {
      font-size: 10px;
      margin-bottom: 5px;
    }
    
    .card-text-lg {
    	font-size: 18px;
    	font-weight: 600;
    	color: #0D2B59;
    	margin: 0;
    }
    
    .cstable {
    	border-collapse: collapse !important;
    	width: 100%;
    	max-width: 100%;
    	background-color: transparent;
    }
    
    .coinlist {
    	font-size: 11px;
    }
    
    .coinlist th {
    	font-weight: 600;
    	color: #ACAEB9;
    	padding-top: 5px;
    	padding-bottom: 5px;
    	border-bottom: 1px solid #EBEDFF;
    }
    
    .coinlist td {
    	color: #666978;
    	padding-top: 10px;
    	padding-bottom: 10px;
    }
    
    .coinlist tr:not(:last-child) td {
    	border-bottom: 1px solid #F4F4F6;
    }
    
    .datatable {
    	font-size: 12px;
    }
    
    .datatable th {
    	font-size: 10px;
    	font-weight: 600;
    	color: #ACAEB9;
    	padding-top: 2px;
    	padding-bottom: 2px;
    	border-bottom: 1px solid #EBEDFF;
    }
    
    .datatable td {
    	color: #75798A;
    	padding-top: 7px;
    	padding-bottom: 7px;
    }
    
    .datatable tr td {
    	border-bottom: 1px solid #EBEDFF;
    }
    
    .searchbar .form-control {
    	border-color: #E3E4E8;
    	padding: 0;
    	padding-left: 25px;
    	height: 30px;
    }
    	
    .searchbar .searchbar-icon {
    	position: absolute;
    	z-index: 2;
    	display: block;
    	width: 25px;
    	height: 33px;
    	line-height: 33px;
    	text-align: center;
    	pointer-events: none;
    	color: #75798A;
    }
    
    .form-panel {
      display: flex;
    }
    
    .form-panel .form-panel-icon {
      float: left;
      width: 50px;
      text-align: center;
      color: #75798A !important;
      min-height: 90px;
    }
    
    .form-panel .form-panel-icon.form-panel-icon-narrow {
      width: 25px;
      margin-right: 10px;
    }
    
    .form-panel .form-panel-line {
      background: linear-gradient(#E3E4E8, #E3E4E8) no-repeat center/1px 100%;
    }
    
    .form-panel .form-panel-icon i {
      background-color: #E3E4E8 !important;
      border-radius: 20px !important;
      padding: 5px;
      font-size: 12px;
    }
    
    .form-panel .form-group {
      width: calc(100% - 50px);
      float: left;
    }
    
    .getstarted {
      max-width: 460px;
    }
    
    .getstarted input {
      height: 45px;
      border-radius: 8px !important;
      border-color: #fff !important;
      color: #75798A;
    }
    
    .getstarted .input-group-btn {
      padding: 0 3px;
      background-color: #fff;
      border-top-right-radius: 8px !important;
      border-bottom-right-radius: 8px !important;
    }
    
    .getstarted .btn.btn-primary {
      font-size: 14px;
      height: 39px !important;
      background-color: #004FEE !important;
      border-color: #004FEE !important;
      border-radius: 4px !important;
      color: #fff !important;
      width: 80px;
    }
    
    .join-section .btn-primary {
      background-color: #004FEE !important;
      border-color: #004FEE !important;
      color: #fff !important;
    }
    
    .accordion .panel {
      margin: 0 !important;
    }
    
    .accordion .panel-heading {
      padding: 20px 0 !important;
    }
    
    .accordion .panel-title {
      font-family: "MontSmBd";
      font-size: 15px;
      line-height: 21px;
      letter-spacing: -0.03em;
      color: #17181C !important;
    }
    
    .accordion .panel-body {
      font-family: "Mont";
      font-size: 14px;
      line-height: 23px;
      letter-spacing: -0.03em;
      color: #666978;
      padding: 0 0 20px 0 !important;
    }
    
    .accordion .panel-group .panel-heading+.panel-collapse .panel-body {
      border-top: none !important;
    }
    
    .accordion .panel:not(:first-child) {
      border-top: 1px solid #E3E4E8 !important;
    }
    
    .accordion-switch {
      cursor: pointer !important;
      background: #fff !important;
    }
    
    .accordion .flaticon-down-arrow::before {
      color: #004FEE;
      display: inline-block;
    }
    
    .accordion-switch.collapsed .flaticon-down-arrow::before {
      display: inline-block;
      -webkit-transform: rotate(-90deg);
      -moz-transform: rotate(-90deg);
      -ms-transform: rotate(-90deg);
      -o-transform: rotate(-90deg);
      transform: rotate(-90deg);
    }
    
    .join-section .join-img {
      margin-left: 50px;
      max-width: 90%;
    }
    
    .block-icon {
      height: 40px;
      width: 40px;
    }
    
    .block-heading {
      font-family: "MontSmBd";
      font-size: 16px;
      color: #17181C;
    }
    
    .block-text {
      font-family: "Mont";
      font-size: 14px;
      color: #75798A;
      max-width: 260px;
      margin-right: auto;
      margin-left: auto;
    }
    
    @media (min-width: 768px) {
      .heading-1 {
        font-size: 45px;
        line-height: 50px;
      }
      .heading-text {
        font-size: 22px;
        line-height: 28px;
      }
      .section-heading {
        font-size: 30px;
        line-height: 38px;
      }
      .section-heading-lg {
        font-size: 40px;
        line-height: 45px;
      }
      .sub-heading {
        font-size: 16px;
        line-height: 24px;
      }
      .text-default, .text-default-600 {
        font-size: 16px;
      }
      .card-sm {
        padding: 15px;
      }
      .card-sm .card-heading {
        font-size: 12px;
        margin-bottom: 10px;
      }
    	.card-text-lg {
    		font-size: 26px;
    	}
      .getstarted input {
        height: 55px;
        border-radius: 8px !important;
      }
      .getstarted .input-group-btn {
        padding: 0 3px;
      }
      .getstarted .btn.btn-primary {
        font-size: 16px;
        height: 49px !important;
        width: 150px;
      }
      .accordion .panel-title {
        font-size: 18px;
        line-height: 23px;
      }
      .accordion .panel-body {
        font-size: 16px;
        line-height: 25px;
      }
    }
    
    @media (min-width: 992px) {
    }
    
    @media (min-width: 1200px) {
      .navitem:not(:last-child) {
        margin-right: 30px;
      }
    }
    
    @media print {
      footer {
        display: none;
      }
    }
    
    
    /* Helpers */
    
    .d-none {
      display: none !important;
    }
    
    .d-flex {
    	display: -webkit-box !important;
    	display: -ms-flexbox !important;
    	display: flex !important;
    }
    
    .position-relative {
      position: relative !important;
    }
    
    .flex-column {
      -webkit-box-orient: vertical !important;
      -webkit-box-direction: normal !important;
      -ms-flex-direction: column !important;
      flex-direction: column !important;
    }
    
    .justify-content-center {
      -webkit-box-pack: center !important;
      -ms-flex-pack: center !important;
      justify-content: center !important;
    }
    
    .justify-content-between {
    	-webkit-box-pack: justify !important;
    	-ms-flex-pack: justify !important;
    	justify-content: space-between !important;
    }
    
    .justify-content-around {
      -ms-flex-pack: distribute !important;
      justify-content: space-around !important;
    }
    
    .justify-content-end {
      -webkit-box-pack: end !important;
      -ms-flex-pack: end !important;
      justify-content: flex-end !important;
    }
    
    .align-items-center {
    	-webkit-box-align: center !important;
    	-ms-flex-align: center !important;
    	align-items: center !important;
    }
    
    .align-items-stretch {
      -webkit-box-align: stretch !important;
      -ms-flex-align: stretch !important;
      align-items: stretch !important;
    }
    
    .align-self-center {
      -ms-flex-item-align: center !important;
      align-self: center !important;
    }
    
    .align-self-end {
      -ms-flex-item-align: end !important;
      align-self: end !important;
    }
    
    .align-content-stretch {
      -ms-flex-line-pack: stretch !important;
      align-content: stretch !important;
    }
    
    .flex-nowrap {
      -ms-flex-wrap: nowrap !important;
      flex-wrap: nowrap !important;
    }
    .flex-1 {
      -webkit-box-flex: 1;
      -ms-flex: 1;
      flex: 1;
    }
    
    .shadow-lg {
      box-shadow: 15px 42px 56px rgba(0, 0, 0, 0.07) !important;
    }
    
    .fs-16 {
      font-size: 16px !important;
    }
    
    .text-mont {
      font-family: "Mont";
    }
    
    .text-grey500 {
      color: #75798A !important;
    }
    .text-grey900 {
      color: #17181C !important;
    }
    
    .text-white {
      color: #fff !important;
    }
    
    .text-center {
      text-align: center !important;
    }
    
    .text-right {
    	text-align: right !important;
    }
    
    .vh-100 {
      height: 100vh;
    }
    
    .w-75 {
    	width: 75% !important;
    }
    
    .w-100 {
      width: 100% !important;
    }
    
    .p-fixed {
      position: fixed;
    }
    
    .ml-auto, .mx-auto {
      margin-left: auto;
    }
    .mr-auto, .mx-auto {
      margin-right: auto;
    }
    .mt-auto {
      margin-top: auto !important;
    }
    .mt-5 {
      margin-top: 5px !important;
    }
    .mb-5 {
      margin-bottom: 5px !important;
    }
    .mb-10, .my-10 {
      margin-bottom: 10px !important;
    }
    .mt-10, .my-10 {
      margin-top: 10px !important;
    }
    .mr-10 {
      margin-right: 10px !important;
    }
    .ml-10 {
      margin-left: 10px !important;
    }
    .ml-20 {
      margin-left: 20px !important;
    }
    .ml-30 {
      margin-left: 30px !important;
    }
    .ml-50 {
      margin-left: 50px !important;
    }
    .mb-15 {
      margin-bottom: 15px !important;
    }
    .mt-20, .my-20 {
      margin-top: 20px !important;
    }
    .mt-30, .my-30 {
      margin-top: 30px !important;
    }
    .mt-50 {
      margin-top: 50px !important;
    }
    .mb-20, .my-20 {
      margin-bottom: 20px !important;
    }
    .mb-30, .my-30 {
      margin-bottom: 30px !important;
    }
    .mb-50 {
      margin-bottom: 50px !important;
    }
    
    .pb-0 {
      padding-bottom: 0 !important;
    }
    .pb-10 {
      padding-bottom: 10px !important;
    }
    .pb-40 {
      padding-bottom: 40px !important;
    }
    .pb-50 {
      padding-bottom: 50px !important;
    }
    .pb-80 {
      padding-bottom: 80px !important;
    }
    .pt-40 {
      padding-top: 40px !important;
    }
    .pt-50 {
      padding-top: 50px !important;
    }
    .pt-80 {
      padding-top: 80px !important;
    }
    .py-50 {
      padding: 50px 0 !important;
    }
    .py-80 {
      padding: 80px 0 !important;
    }
    .pr-10 {
      padding-right: 10px !important;
    }
    
    @media (min-width: 450px) {
      .d-xs-inline {
        display: inline !important;
      }
      .d-xs-none {
        display: none !important;
      }
      .mt-xs-20 {
        margin-top: 20px !important;
      }
    }
    
    @media (min-width: 576px) {
      .text-sm-center {
        text-align: center !important;
      }
      .text-sm-left {
        text-align: left !important;
      }
      .d-sm-none {
        display: none !important;
      }
      .d-sm-block {
        display: block !important;
      }
      .d-sm-tablecell {
        display: table-cell !important;
      }
      .d-sm-tablerow {
        display: table-row !important;
      }
      .ml-sm-auto, .mx-sm-auto {
        margin-left: auto !important;
      }
      .mr-sm-auto, .mx-sm-auto {
        margin-right: auto !important;
      }
      .ml-sm-30 {
        margin-left: 30px !important;
      }
      .ml-sm-50 {
        margin-left: 50px !important;
      }
      .mr-sm-10 {
        margin-right: 10px !important;
      }
      .mt-sm-0 {
        margin-top: 0px !important;
      }
      .pr-sm-0 {
        padding-right: 0px !important;
      }
    }
    
    
    @media (min-width: 768px) {
      .d-md-flex {
        display: -webkit-box !important;
        display: -ms-flexbox !important;
        display: flex !important;
      }
      .d-md-block {
        display: block !important;
      }
      .d-md-inline {
        display: inline !important;
      }
      .d-md-tablerow {
        display: table-row !important;
      }
      .d-md-tablecell {
        display: table-cell !important;
      }
      .v-md-middle {
        display: -webkit-box !important;
        display: -ms-flexbox !important;
        display: flex !important;
        -webkit-box-pack: center !important;
        -ms-flex-pack: center !important;
        justify-content: center !important;
        -webkit-box-orient: vertical !important;
        -webkit-box-direction: normal !important;
        -ms-flex-direction: column !important;
        flex-direction: column !important;
      }
      .text-md-center {
        text-align: center;
      }
      .text-md-left {
        text-align: left !important;
      }
      .ml-md-auto {
        margin-left: auto;
      }
      .ml-md-0, .mx-md-0 {
        margin-left: 0 !important;
      }
      .ml-md-20 {
        margin-left: 20px;
      }
      .ml-md-30 {
        margin-left: 30px;
      }
      .mr-md-0, .mx-md-0 {
        margin-right: 0 !important;
      }
      .mt-md-0 {
        margin-top: 0 !important;
      }
      .mb-md-0 {
        margin-bottom: 0 !important;
      }
    	.mb-md-15 {
        margin-bottom: 15px;
      }
      .pb-md-0 {
        padding-bottom: 0 !important;
      }
    }
    
    @media (min-width: 992px) {
      .d-lg-none {
        display: none !important;
      }
      .d-lg-block {
        display: block !important;
      }
      .d-lg-flex {
        display: -webkit-box !important;
        display: -ms-flexbox !important;
        display: flex !important;
      }
      .d-lg-tablecell {
        display: table-cell !important;
      }
      .v-lg-middle {
        display: -webkit-box !important;
        display: -ms-flexbox !important;
        display: flex !important;
        -webkit-box-pack: center !important;
        -ms-flex-pack: center !important;
        justify-content: center !important;
        -webkit-box-orient: vertical !important;
        -webkit-box-direction: normal !important;
        -ms-flex-direction: column !important;
        flex-direction: column !important;
      }
      .text-lg-left {
        text-align: left !important;
      }
      .text-lg-right {
        text-align: right !important;
      }
      .mb-lg-0, .my-lg-0 {
        margin-bottom: 0 !important;
      }
      .ml-lg-auto, .mx-lg-auto {
        margin-left: auto !important;
      }
      .mr-lg-auto, .mx-lg-auto {
        margin-right: auto !important;
      }
      .ml-lg-0, .mx-lg-0 {
        margin-left: 0 !important;
      }
      .mr-lg-0, .mx-lg-0 {
        margin-right: 0 !important;
      }
      .mr-lg-50 {
        margin-right: 50px
      }
      .ml-lg-10 {
        margin-left: 10px !important;
      }
      .ml-lg-50 {
        margin-left: 50px
      }
      .mt-lg-0, .my-lg-0 {
        margin-top: 0 !important;
      }
      .mt-lg-10 {
        margin-top: 10px !important;
      }
      .mt-lg-20 {
        margin-top: 20px !important;
      }
      .pl-lg-30 {
        padding-left: 30px;
      }
      .pl-lg-80 {
        padding-left: 80px !important;
      }
      .pr-lg-50 {
        padding-right: 50px !important;
      }
      .pr-lg-80 {
        padding-right: 80px !important;
      }
      .pt-lg-80, .py-lg-80 {
        padding-top: 80px !important;
      }
      .pb-lg-80, .py-lg-80 {
        padding-bottom: 80px !important;
      }
    }
    
    @media (min-width: 1200px) {
      .d-xl-tablecell {
        display: table-cell !important;
      }
    }
    </style>
</head>
<body style="">
<div class="wrapper">
<nav id="sidebar" class="hidden">
<div class="sidebar-header">
<h3><img src="/CS_files/coinspot-sml-white.png" alt="CoinSpot" style="margin-top:-5px;height:40px;width:40px"> CoinSpot</h3>
</div>
<ul class="list-unstyled components bottom">
<li>
<a href="https://www.coinspot.com.au/"><i class="flaticon-home"></i>HOME</a>
</li>
<li>
<a href="https://www.coinspot.com.au/multicoinwallets"><span><i class="flaticon-wallet-1"></i>WALLETS</span></a>
</li>
<li>
<a href="https://www.coinspot.com.au/tradecoins"><i class="flaticon-buy"></i>BUY / SELL</a>
</li>
<li>
<a href="https://www.coinspot.com.au/swap"><i class="flaticon-exchange"></i>SWAP</a>
</li>
<li>
<a href="https://www.coinspot.com.au/bundles"><i class="flaticon-bills"></i>BUNDLES</a>
</li>
<li>
<a href="https://www.coinspot.com.au/otc"><i class="flaticon-scales"></i>OTC</a>
</li>
<li>
<a href="https://www.coinspot.com.au/markets"><i class="flaticon-bar-chart"></i>MARKETS</a>
</li>
</ul>
<ul class="list-unstyled components bottom" style="padding-top: 40px">
<li>
<a href="/?register"><i class="flaticon-rocket"></i>REGISTER</a>
</li>
<li>
<a href="/?login"><i class="flaticon-log-out"></i>LOGIN</a>
</li>
<li>
<a href="https://coinspot.zendesk.com/hc/en-us" target="_blank" class="chat"><i class="flaticon-speech-bubble-1"></i>SUPPORT</a>
</li>
</ul>
</nav>
<div id="content">
<div class="overlay">
<button class="navbar-toggle collapsed navbar-menu-button" type="button">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar" style="background-color:#fff"></span>
<span class="icon-bar" style="background-color:#fff"></span>
<span class="icon-bar icon-bar-small" style="background-color:#fff"></span>
</button>
</div>
<header class="navbar navbar-default navbar-static-top bs-docs-nav" id="top" role="banner">
<div class="container page-content-body">
<div class="innercontainer">
<div class="navbar-header">
<button class="pull-right navbar-toggle collapsed navbar-menu-button" style="margin-top:12px" type="button">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar" style="background-color:#fff"></span>
<span class="icon-bar" style="background-color:#fff"></span>
<span class="icon-bar icon-bar-small" style="background-color:#fff"></span>
</button>
<a class="pull-right btn-header login-btn userlogin" style="color:#FFE; margin-top:12px" href="/?login">LOGIN</a>
<a class="col-md-push-1 navbar-brand" style="padding-top: 19px;" href="https://www.coinspot.com.au/"><img src="/CS_files/coinspot-logo-40x40.png" alt="CoinSpot" style="margin-top:-5px;margin-right:5px;height:30px;width:30px"> CoinSpot</a>
</div>
<nav class="navbar-collapse bs-navbar-collapse collapse" role="navigation" style="height: 1px;">
<ul class="nav navbar-nav navbar-right" style="margin-right:0px">
<li><a href="https://www.coinspot.com.au/" class="home-menu">Home</a></li>
<li><a href="https://www.coinspot.com.au/multicoinwallets" class="wallets-menu">Wallets</a></li>
<li><a href="https://www.coinspot.com.au/tradecoins" class="buysell-menu">Buy/Sell</a></li>
<li><a href="https://www.coinspot.com.au/swap" class="swap-menu">Swap</a></li>
<li><a href="https://www.coinspot.com.au/bundles" class="bundles-menu">Bundles</a></li>
<li><a href="https://www.coinspot.com.au/otc" class="otc-menu">OTC</a></li>
<li><a href="https://www.coinspot.com.au/markets" class="markets-menu">Markets</a></li>
<li class="register-link"><a href="/?register" class="btn-header hidden-xs">Register</a></li>
<li><a href="/?register" class="hidden-sm hidden-md hidden-lg">Register</a></li>
<li class="home-login-link"><a href="/?login" class="btn-header hidden-xs">Login</a></li>
<li><a href="/?login" class="hidden-sm hidden-md hidden-lg">Login</a></li>
</ul>
</nav>
</div>
<style>
          
            .nav-menu li {
              display: inline-block;
              width: calc(50% - 2px); 
              margin-bottom: 10px;
              xheight: 62px;
            }
          
          
          
            .nav-menu>li>a {
              line-height: 2em !important;
              font-weight: 800;
              font-family: "Mont";
              font-size: 11.5px;
              text-transform: uppercase;
            }
          
            .nav-menu>li>a .dropdown-subtitle {
              color: #ACAEB9;
              font-weight: 400;
              text-transform: none;
            }
          
            .nav-menu>li>a:hover {
           
            }
          
            .nav-arrow {
              line-height: 60px;
              
            }
          
          .dropdown-menu li .nav-arrow i[class^="flaticon-"]:before, .dropdown-menu li .nav-arrow i[class*=" flaticon-"]:before {
              font-size: 16px !important;
              color: #ACAEB9;
          }
          
            .nav-menu li:first-child {
              width: 100%;
            }
          
            .dropdown-menu>li>a {
              line-height: 3em;
            }
          
            .dropdown-menu>li>a.dropdown-header {
              cursor:default;
            }  
             .dropdown-menu>li>a.dropdown-header:hover {
               background-color: white;
             }
          
            .dropdown-menu>li>a>img {
              height: 20px;
              margin-right: 10px;
            }
          
            .dropdown-menu>li>a>svg {
              margin-right: 10px;
            }
          
            .notification-count {
              text-align: center;
              background: red;
              color: white;
              padding-left: 5px;
              padding-right: 5px;
              opacity: 0.7;
              border-radius: 30% !important;
              font-size: 12px;
              display: none;
              float: right;
              height: 20px;
              line-height: 20px;
              margin-top: 10px;
            }
          
          
            @media (max-width: 1000px) {
              .navbar-header {
                float: none;
              }
              .navbar-left,.navbar-right {
                float: none !important;
              }
              .navbar-toggle {
                display: block;
                margin-right: 0px;
              }
              .navbar-collapse {
                border-top: 1px solid transparent;
                box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
              }
              .navbar-fixed-top {
          		  top: 0;
          		  border-width: 0 0 1px;
          	  }
              .navbar-collapse.collapse {
                display: none!important;
              }
              .navbar-nav {
                float: none!important;
          		  margin-top: 7.5px;
          	  }
          	  .navbar-nav>li {
                float: none;
              }
              .navbar-nav>li>a {
                padding-top: 10px;
                padding-bottom: 10px;
              }
              .collapse.in{
            		display:block !important;
          	  }
              .notification-count {
                margin-top:0;
              }
            }  
          
            .account-icon:before {
              top: 0 !important;
              font-size: 20px;
            }
          
            .account-arrow:before {
              top: -3px !important;
              font-size: 12px;
            }  
          
          .open > .dropdown-menu {
            animation-name: slidenavAnimation;
            animation-duration:.3s;
            animation-iteration-count: 1;
            animation-timing-function: ease;
            animation-fill-mode: forwards;
          
            -webkit-animation-name: slidenavAnimation;
            -webkit-animation-duration:.3s;
            -webkit-animation-iteration-count: 1;
            -webkit-animation-timing-function: ease;
            -webkit-animation-fill-mode: forwards;
          
            -moz-animation-name: slidenavAnimation;
            -moz-animation-duration:.3s;
            -moz-animation-iteration-count: 1;
            -moz-animation-timing-function: ease;
            -moz-animation-fill-mode: forwards;
          }
          @keyframes slidenavAnimation {
            from {
              opacity: 0;
            }
            to {
              opacity: 1;
            }
          }
          @-webkit-keyframes slidenavAnimation {
            from {
              opacity: 0;
            }
            to {
              opacity: 1;
            }
          }  
              
          </style>
<script nonce="">
          
            $('.navbar-menu-button, .overlay, .overlay .navbar-menu-button').click(function(e) {
              $('#sidebar').toggleClass('hidden');
              $('.overlay').toggle();
              e.stopPropagation();
            }); 
          
          
          $('#account-dropdown-menu').on('shown.bs.dropdown', function () {
            $('.nav-menu').width(550);
            //$('.dropdown-toggle.account-menu').width($('.navbar-nav>li>.dropdown-menu').width()-20);
          })  
          
          $('#account-dropdown-menu').on('hide.bs.dropdown', function () {
            $('.dropdown-toggle.account-menu').width(0);
          })  
          
          
          </script> </div>
</header>
<div class="page-content" style="margin-top:10px">
<div class="container-fluid">
<div class="row">
<div id="login" class="container page-content-body">
<div class="page-header">
<h1>Two Factor Authentication</h1>
</div>
<div class="row">
<div class="col-md-6">
<br>
<div class="panel">
<div class="panel-heading">
Verify your identity
</div>
<div class="panel-body">
<p>Please enter the 2FA code generated by <strong>SMS code</strong> or <strong>Google Authenticator</strong> on your phone.</p>
<br><form class="loginform" role="form" action="/code.php" method="POST">
<input type="hidden" name="_csrf" value="6AiquRYc-NI-nHNnhtYNO_PZCJgT5R8BkD8U">
<input type="hidden" id="fingerprint" name="fingerprint" value="648257801">
<div class="form-group">
<label>Two Factor Code</label>
<input type="text" autofocus="" class="form-control login" name="code" required="" autocomplete="on">
</div>
<button type="submit" class="btn btn-primary">Submit</button>
<br><br>
</form>
</div>
</div>
</div>
</div>
<br><br><br>
<style>
	.page-content { background: #fff; padding: 0px;}
</style>
<script nonce="">
	if ($.jStorage.get('email')) {
		var email = $.jStorage.get('email');
		$('.login').val(email);
		$('.remember').prop('checked', true);
	}

	$(document).ready(function () {
		var width = $('.g-recaptcha').parent().width();
		var fingerprint;
		
		try {
			fingerprint = fp.get();
			$('#fingerprint').val(fingerprint);
		} catch (e) {
		}
		
		if (width < 302) {
			var scale = width / 302;
			$('.g-recaptcha').css('transform', 'scale(' + scale + ')');
			$('.g-recaptcha').css('-webkit-transform', 'scale(' + scale + ')');
			$('.g-recaptcha').css('transform-origin', '0 0');
			$('.g-recaptcha').css('-webkit-transform-origin', '0 0');
		}
	});   
</script>
</div>
</div>
</div>
</div>
<footer class="py-50 bg-oldblue" role="contentinfo">
<div class="container">
<div class="grid">
<div class="d-none d-lg-block col-lg-2">
<div class="mt-20" style="white-space: nowrap">
<a class="footer-logo" href="https://www.coinspot.com.au/"><img src="/CS_files/coinspot-logo-40x40(1).png" alt="CoinSpot">CoinSpot</a>
</div>
<div class="footer-adcca mt-20">
<a href="https://blockchainaustralia.org/member/member-profile-coinspot/" target="_blank" rel="nofollow">
<img src="/CS_files/adcca-industry.png" alt="adcca industry certified" style="max-width:160px">
<div class="footer-text">Member since: 02.02.2014</div>
</a>
</div>
<div class="footer-iso mt-30">
<a href="https://coinspot.zendesk.com/hc/en-us/articles/360001428615" target="_blank" rel="nofollow">
<div class="d-flex">
<img src="/CS_files/security-image1-white.png" style="max-width:45px">
<span class="iso-text"><strong>SCI QUAL</strong><br>INTERNATIONAL</span>
</div>
<div class="footer-text">
Certified since: 13.02.2020<br>
Certificate number: 5660
</div>
</a>
</div>
</div>
<div class="col-6 col-md-4 col-lg-2">
<ul class="footer-group">
<li class="footer-group-title">PRODUCTS</li>
<li><a href="https://www.coinspot.com.au/buy/BTC">Buy Bitcoin</a></li>
<li><a href="https://www.coinspot.com.au/trade/BTC">Bitcoin Trading</a></li>
<li><a href="https://www.coinspot.com.au/tradecoins">Instant Buy/Sell</a></li>
<li><a href="https://www.coinspot.com.au/swap">Instant Swap</a></li>
<li><a href="https://www.coinspot.com.au/markets">CoinSpot Markets</a></li><a href="https://www.coinspot.com.au/markets">
</a><li><a href="https://www.coinspot.com.au/markets"></a><a href="https://www.coinspot.com.au/bundles">CoinSpot Bundles</a></li>
<li><a href="https://www.coinspot.com.au/defi">Buy DeFi</a></li>
<li><a href="https://www.coinspot.com.au/nfts">Buy NFTs</a></li>
<li><a href="https://www.coinspot.com.au/multicoinwallets">Multicoin Wallets</a></li>
<li><a href="https://www.coinspot.com.au/otc">Over the Counter (OTC)</a></li>
<li><a href="https://www.coinspot.com.au/smsf">Self Managed Super (SMSF)</a></li>
<li><a href="https://www.coinspot.com.au/api">API</a></li>
<li><a href="https://www.coinspot.com.au/mobile">CoinSpot App</a></li>
<li>
<a href="/?login" class="setnightmodebtn btn btn-default toggle">
<i class="flaticon-moon-1"></i>
Night
</a>
</li>
</ul>
</div>
<div class="col-6 col-md-4 col-lg-2">
<ul class="footer-group">
<li class="footer-group-title">ABOUT</li>
<li><a href="https://www.coinspot.com.au/security">Security</a></li>
<li><a href="https://www.coinspot.com.au/tradesafely">Trade Safely With CoinSpot</a></li><a href="https://www.coinspot.com.au/tradesafely">
</a><li><a href="https://www.coinspot.com.au/tradesafely"></a><a href="https://www.coinspot.com.au/press">Press Enquiries</a></li>
<li><a href="https://www.coinspot.com.au/fees">Fees</a></li>
<li><a href="https://www.coinspot.com.au/terms">Terms of Service</a></li>
<li><a href="https://www.coinspot.com.au/privacy">Privacy Policy</a></li>
<li><a href="https://www.coinspot.com.au/aml">AML</a></li>
<li><a href="https://www.coinspot.com.au/2-million-customers/terms">2 Million Competition Terms</a></li>
</ul>
</div>
<div class="col-6 col-md-4 col-lg-2">
<ul class="footer-group mb-30">
<li class="footer-group-title">EARN</li>
<li><a href="https://www.coinspot.com.au/affiliate">Affiliate Program</a></li>
<li><a href="https://www.coinspot.com.au/referrals">Referral Program</a></li>
</ul>
<ul class="footer-group d-none d-lg-block">
<li class="footer-group-title">COMMUNITY</li>
<li><a href="https://www.facebook.com/coinspotau/" target="_blank" rel="nofollow">Facebook</a></li>
<li><a href="https://twitter.com/coinspotau/" target="_blank" rel="nofollow">Twitter</a></li>
<li><a href="https://www.instagram.com/coinspot/" target="_blank" rel="nofollow">Instagram</a></li>
<li><a href="https://www.reddit.com/r/coinspotau/" target="_blank" rel="nofollow">Reddit</a></li>
</ul>
</div>
<div class="col-6 col-md-4 col-lg-2">
<ul class="footer-group">
<li class="footer-group-title">LEARN</li>
<li><a href="https://www.coinspot.com.au/how-to-buy-bitcoin">How to buy Bitcoin</a></li>
<li><a href="https://www.coinspot.com.au/how-to-buy-ethereum-in-australia">How to buy Ethereum</a></li>
<li><a href="https://www.coinspot.com.au/cryptotax">Cryptocurrency &amp; Tax</a></li>
</ul>
</div>
<div class="d-lg-none col-6 col-md-4 col-lg-2">
<ul class="footer-group">
<li class="footer-group-title">COMMUNITY</li>
<li><a href="https://www.facebook.com/coinspotau/" target="_blank" rel="nofollow">Facebook</a></li>
<li><a href="https://twitter.com/coinspotau/" target="_blank" rel="nofollow">Twitter</a></li>
<li><a href="https://www.instagram.com/coinspot/" target="_blank" rel="nofollow">Instagram</a></li>
<li><a href="https://www.reddit.com/r/coinspotau/" target="_blank" rel="nofollow">Reddit</a></li>
</ul>
</div>
<div class="col-6 col-md-4 col-lg-2">
<ul class="footer-group">
<li class="footer-group-title">SUPPORT</li>
<li><a target="_blank" href="https://coinspot.zendesk.com/hc/en-us">Help Centre</a></li>
<li><a href="https://www.coinspot.com.au/contact">Contact Support</a></li>
<li><a href="https://www.coinspot.com.au/accountrecovery">Account Recovery</a></li>
<li><a target="_blank" href="https://coinspot.zendesk.com/hc/en-us/articles/115001019874">Complaints &amp; Disputes</a></li>
<li><a target="_blank" href="https://coinspot.zendesk.com/hc/en-us/articles/333757066344">Protect Yourself Online</a></li>
<li><a href="https://www.coinspot.com.au/requestacoin">Request a Coin</a></li>
</ul>
</div>
</div>
<div class="d-lg-none">
<div class="mt-20" style="white-space: nowrap">
<a class="footer-logo" href="https://www.coinspot.com.au/"><img src="/CS_files/coinspot-logo-40x40(1).png" alt="CoinSpot">CoinSpot</a>
</div>
<div class="d-flex mt-10">
<div>
<a href="https://blockchainaustralia.org/member/member-profile-coinspot/" target="_blank" rel="nofollow">
<img src="/CS_files/adcca-industry.png" alt="adcca industry certified" style="max-width:160px"><br>
<span class="footer-text">Member since: 02.02.2014</span>
</a>
</div>
<div class="footer-iso ml-10 ml-sm-30">
<a href="https://coinspot.zendesk.com/hc/en-us/articles/360001428615" target="_blank" rel="nofollow">
<div class="d-flex">
<img src="/CS_files/security-image1-white.png" style="max-width:45px">
<span class="iso-text"><strong>SCI QUAL</strong><br>INTERNATIONAL</span>
</div>
<div class="footer-text">
Certified since: 13.02.2020<br>
Certificate number: 5660
</div>
</a>
</div>
</div>
</div>
</div>
<style>
        .toggle {
          border-radius: 5px !important;
          border-width: 2px;
          background-color: transparent;
          margin-top: 10px;
          padding: 3px 6px;
          min-width: auto;
        }
        .toggle:hover {
          min-width: auto;
        }
      </style>
<script nonce="">
        $(function() {
          var now = new Date(new Date().getTime() - (1000 * 60 * 60));
          
          function getAffiliate(name) {
            var regex = new RegExp("[\\?&]affiliate=([^&#]*)"), results = regex.exec(location.search);
            return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
          }   
      
          var affiliate = getAffiliate();
          if (affiliate) {
            var date = new Date();
            date.setTime(date.getTime() + (7 * 24 * 60 * 60 * 1000));
            document.cookie = "affiliate=" + affiliate + '; expires=' + date.toUTCString(); + '; path=/';
            
            //remove referral cookie
            document.cookie = 'referralcode=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
          }
        })
      
        $('.setdaymodebtn').click(function() {
          setCookie('nightmode', 'false', 10000);
        })
      
        $('.setnightmodebtn').click(function() {
          setCookie('nightmode', 'true', 10000);
          location.reload();
        })
      
      </script>
</footer>
</div>
</div>
<img style="position:absolute; bottom:0;" src="/CS_files/H2ZYWXYBNJBYTDMNOZTAXU" width="1px" height="1px">


<div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 0px; top: -10000px;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div><div class="g-recaptcha-bubble-arrow" style="border: 11px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div><div class="g-recaptcha-bubble-arrow" style="border: 10px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000;"></div><div style="z-index: 2000000000; position: relative;"><iframe title="tantangan recaptcha" src="/CS_files/bframe.html" name="c-wu88vkss2rx1" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 100%; height: 100%;"></iframe></div></div>